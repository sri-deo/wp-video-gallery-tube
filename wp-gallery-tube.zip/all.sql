
-- ************************************** `wp_gallery_tube_studios`

CREATE TABLE `wp_gallery_tube_studios`
(
 `id`          int NOT NULL AUTO_INCREMENT ,
 `studio_nicename` varchar(500)  NULL ,
 `studio_name` varchar(500) NOT NULL ,
 `description` text NULL ,
 `url`         text  NULL ,
 `logo`        text NULL ,
 `date_created` timestamp NOT NULL ,

PRIMARY KEY (`id`)
);


-- ************************************** `wp_gallery_tube_pornstars`

CREATE TABLE `wp_gallery_tube_pornstars`
(
 `id`           int NOT NULL AUTO_INCREMENT ,
 `name`         text NOT NULL ,
 `slug`         varchar(500) NOT NULL,
 `photo`          text NULL ,
 `country`      varchar(100) NULL ,
 `birth`        date NULL ,
 `bio`          text NULL ,
 `height`       varchar(45) NULL ,
 `weight`       varchar(45) NULL ,
 `aliases`      text NULL ,
 `date_created` timestamp NOT NULL ,

PRIMARY KEY (`id`)
);


-- ************************************** `wp_gallery_tube_tags`

CREATE TABLE `wp_gallery_tube_tags`
(
 `id`          int NOT NULL AUTO_INCREMENT ,
 `name`        text NOT NULL ,
 `description` text NULL ,

PRIMARY KEY (`id`)
);


-- ************************************** `wp_gallery_tube`

CREATE TABLE `wp_gallery_tube`
(
 `id`              int NOT NULL AUTO_INCREMENT ,
 `title`           text NOT NULL ,
 `video_length`    varchar(45) NULL ,
 `description`     text NULL ,
 `releaseDate`     varchar(45) NULL ,
 `video_url`       text NOT NULL ,
 `fps`             int NULL ,
 `degrees`         int NULL ,
 `src_image`       text NOT NULL ,
 `site_src`        text NOT NULL ,
 `scene_identity` varchar(50) NOT NULL ,
 `date_created`    timestamp NOT NULL ,
 `studio`          int NOT NULL ,

PRIMARY KEY (`id`),
KEY `fk_studio` (`studio`),
CONSTRAINT `FK_studio` FOREIGN KEY `fk_studio` (`studio`) REFERENCES `wp_gallery_tube_studios` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
);



-- ************************************** `wp_gallery_tube_scene_tag`

CREATE TABLE `wp_gallery_tube_scene_tag`
(
 `tube_id` int NOT NULL ,
 `tag_id`  int NOT NULL ,

PRIMARY KEY (`tube_id`, `tag_id`),
KEY `fkIdx_218` (`tube_id`),
CONSTRAINT `FK_tube_tag` FOREIGN KEY `fkIdx_218` (`tube_id`) REFERENCES `wp_gallery_tube` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
KEY `fkIdx_235` (`tag_id`),
CONSTRAINT `FK_tag` FOREIGN KEY `fkIdx_235` (`tag_id`) REFERENCES `wp_gallery_tube_tags` (`id`)
);



-- ************************************** `wp_gallery_tube_scene_star`

CREATE TABLE `wp_gallery_tube_scene_star`
(
 `tube_id`     int NOT NULL ,
 `pornstar_id` int NOT NULL ,

PRIMARY KEY (`tube_id`, `pornstar_id`),
KEY `fkIdx_242` (`pornstar_id`),
CONSTRAINT `FK_star` FOREIGN KEY `fkIdx_242` (`pornstar_id`) REFERENCES `wp_gallery_tube_pornstars` (`id`),
KEY `fkIdx_247` (`tube_id`),
CONSTRAINT `FK_tube_star` FOREIGN KEY `fkIdx_247` (`tube_id`) REFERENCES `wp_gallery_tube` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
);
